/* The Daily Drip - scroll & parallax
   Heavy scroll = Lenis with a low lerp (lower = heavier/slower to settle).
   All scroll animations are GSAP ScrollTrigger with scrub.
   Shared by every page: each block only runs when its section exists. */

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
// Phones / tablets: native scroll + only the key animations, so scrolling stays smooth
const lite = window.matchMedia('(hover: none) and (pointer: coarse), (max-width: 760px)').matches;
const $ = (s) => document.querySelector(s);
// Native touch scroll runs on the compositor; a little scrub smoothing hides the frame-to-frame jitter
const SCRUB = lite ? 0.6 : true;
gsap.registerPlugin(ScrollTrigger);
ScrollTrigger.config({ ignoreMobileResize: true });   // no re-layout when the address bar shows/hides

/* ---------- Language: EN (default) / NL ----------
   Dutch copy lives in the HTML as data-nl="…" on each element; the English is whatever
   the element contains. The choice is remembered per visitor. */
const i18n = [...document.querySelectorAll('[data-nl]')];
i18n.forEach((el) => { el.dataset.en = el.tagName === 'TITLE' ? el.textContent : el.innerHTML; });
const splitWords = (el) => {
  [...el.childNodes].forEach((node) => {
    if (node.nodeType !== Node.TEXT_NODE) return;
    const frag = document.createDocumentFragment();
    node.textContent.split(/(\s+)/).forEach((part) => {
      if (!part.trim()) { frag.append(part); return; }
      const s = document.createElement('span');
      s.className = 'w'; s.textContent = part; frag.append(s);
    });
    node.replaceWith(frag);
  });
  return el.querySelectorAll('.w');
};
let lang = 'en';
const setLang = (next, live) => {
  lang = next;
  i18n.forEach((el) => {
    const txt = el.dataset[next];
    if (el.tagName === 'TITLE') el.textContent = txt; else el.innerHTML = txt;
    // Already-animated paragraphs: re-split and show fully lit
    if (live && el.matches('.js-words') && !reduceMotion) gsap.set(splitWords(el), { opacity: 1 });
  });
  document.documentElement.lang = next;
  // "NL / ENG" buttons: the active language is fully white, the other faded
  document.querySelectorAll('.js-lang').forEach((b) => {
    b.setAttribute('aria-label', next === 'nl' ? 'Switch to English' : 'Wissel naar Nederlands');
    b.querySelectorAll('.lang-opt').forEach((o) => o.classList.toggle('is-on', o.dataset.l === next));
  });
  try { localStorage.setItem('tdd-lang', next); } catch (e) {}
};
let savedLang = null;
try { savedLang = localStorage.getItem('tdd-lang'); } catch (e) {}
setLang(savedLang === 'nl' ? 'nl' : 'en', false);
document.querySelectorAll('.js-lang').forEach((b) => b.addEventListener('click', () => setLang(lang === 'nl' ? 'en' : 'nl', true)));

/* ---------- Heavy smooth scroll (desktop only) ---------- */
let lenis = null;
if (!reduceMotion && !lite) {
  lenis = new Lenis({
    lerp: 0.055,          // 0.1 = default; 0.04-0.06 feels heavy. Tune here.
    wheelMultiplier: 0.8, // less distance per wheel tick = more weight
    smoothWheel: true,
  });
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add((t) => lenis.raf(t * 1000));
  gsap.ticker.lagSmoothing(0);
}

/* ---------- Menu overlay (opened from the pill) ---------- */
const menuBtns = document.querySelectorAll('.js-menu-btn');
const menu = $('.menu');
const setMenu = (open) => {
  document.body.classList.toggle('menu-open', open);
  menuBtns.forEach((b) => {
    b.setAttribute('aria-expanded', open);
    b.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
  menu.setAttribute('aria-hidden', !open);
  if (lenis) open ? lenis.stop() : lenis.start();
  if (open) gsap.fromTo('.menu__list li', { yPercent: 110 }, { yPercent: 0, duration: 0.9, stagger: 0.06, ease: 'power4.out', delay: 0.15 });
};
menuBtns.forEach((b) => b.addEventListener('click', () => setMenu(!document.body.classList.contains('menu-open'))));
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMenu(false); });

/* ---------- Pill nav + hero logo ----------
   The LAP-style pill sits at the bottom of the screen from the start (it rises in on load).
   The big logo top-left fades out once the next section fills PILL_AT of the screen
   (the pill has its own logo) and fades back in when you scroll up. */
const PILL_AT = 0.5;
const firstSection = $('main > section');
let pastHero = false;
requestAnimationFrame(() => setTimeout(() => document.body.classList.add('pill-in'), reduceMotion ? 0 : 600));

const setPill = (on) => {
  if (on === pastHero) return;
  pastHero = on;
  document.body.classList.toggle('past-hero', on);
};

let pillLimit = 0, payoffLimit = 0;
const hasPayoff = !!$('.logo__payoff');
const measurePill = () => {
  const vh = document.documentElement.clientHeight;
  const end = firstSection ? firstSection.offsetTop + firstSection.offsetHeight : 0;
  pillLimit = end - vh * (1 - PILL_AT);
  payoffLimit = end - vh;               // the moment the next section peeks in at the bottom
};
const checkPill = () => {
  setPill(window.scrollY > pillLimit);
  if (hasPayoff) document.body.classList.toggle('payoff-out', window.scrollY > payoffLimit);
};
measurePill();
window.addEventListener('resize', () => { measurePill(); checkPill(); });
window.addEventListener('load', measurePill);
let ticking = false;
window.addEventListener('scroll', () => {
  if (ticking) return;
  ticking = true;
  requestAnimationFrame(() => { ticking = false; checkPill(); });
}, { passive: true });
checkPill();

/* Same-page anchors glide through Lenis (also from inside the menu) */
document.querySelectorAll('a[href*="#"]').forEach((a) => {
  a.addEventListener('click', (e) => {
    const url = new URL(a.href);
    const page = (p) => p.replace(/index\.html$/, '');
    if (page(url.pathname) !== page(location.pathname)) return;
    const target = url.hash && $(url.hash);
    setMenu(false);
    if (target && lenis) { e.preventDefault(); lenis.scrollTo(target, { duration: 2.2 }); }
  });
});

/* ---------- Forms: sent straight to info@thedailydrip.nl, never via the mail app ----------
   WordPress theme (window.TDD is set): posted in the background to WordPress, which emails it.
   Static site: posted to FormSubmit (formsubmit.co). FormSubmit needs no account: the very first
   submission sends an activation email to info@thedailydrip.nl - click the link in it once.
   If the background request fails, the form posts itself the classic way (to WordPress or
   FormSubmit), which sends the visitor back here with ?sent=1. */
const FORM_TO = 'info@thedailydrip.nl';
const WP = window.TDD && window.TDD.ajaxUrl;
const formText = {
  en: { sending: 'Sending…', ok: 'Thanks! Your message has been sent. We\'ll get back to you soon.', missing: 'Please fill in your name, a valid email and a message.', fail: `Sending didn't work. Please email us at ${FORM_TO}.` },
  nl: { sending: 'Versturen…', ok: 'Bedankt! Je bericht is verstuurd. We nemen snel contact met je op.', missing: 'Vul je naam, een geldig e-mailadres en een bericht in.', fail: `Versturen lukte niet. Mail ons via ${FORM_TO}.` },
};
document.querySelectorAll('.js-form').forEach((form) => {
  const status = form.querySelector('.form__status');
  const btn = form.querySelector('button[type="submit"]');
  const say = (key) => { status.textContent = formText[lang][key]; };
  const next = form.querySelector('[name="_next"]');
  if (next) next.value = `${location.origin}${location.pathname}?sent=1#${form.closest('section').id}`;
  const sent = new URLSearchParams(location.search).get('sent');
  if (sent === '1') say('ok');                  // back from a classic post
  if (sent === '0' || status.dataset.state === 'fail') say('fail');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const invalid = [...form.querySelectorAll('[required]')].filter((f) => !f.checkValidity());
    form.querySelectorAll('.is-invalid').forEach((f) => f.classList.remove('is-invalid'));
    if (invalid.length) { invalid.forEach((f) => f.classList.add('is-invalid')); invalid[0].focus(); say('missing'); return; }
    const data = new FormData(form);
    if (data.get('_honey')) return;               // spam bot filled the hidden field
    if (!WP) data.set('_replyto', data.get('Email'));
    if (WP) { let l = 'en'; try { l = localStorage.getItem('tdd-lang') === 'nl' ? 'nl' : 'en'; } catch (e) {} data.set('lang', l); }   // language of the confirmation email
    btn.disabled = true; say('sending');
    try {
      // FormData = a "simple" request, so no CORS preflight that browsers/blockers can trip over
      const url = WP || `https://formsubmit.co/ajax/${FORM_TO}`;
      const res = await fetch(url, { method: 'POST', body: data, headers: { Accept: 'application/json' }, credentials: 'same-origin' });
      const json = await res.json().catch(() => ({}));
      if (WP && res.status >= 400 && res.status < 500) { say('fail'); return; }   // refused (spam check / missing fields)
      if (!res.ok || String(json.success) === 'false') throw new Error(json.message || res.status);
      form.reset(); say('ok');
    } catch (err) {
      console.warn('[form] background send failed, posting directly:', err);
      HTMLFormElement.prototype.submit.call(form);  // classic POST, never the mail app
    } finally { btn.disabled = false; }
  });
});

/* ---------- Menu page: tab of the section in view is highlighted ---------- */
document.querySelectorAll('.carte-tabs a').forEach((tab) => {
  const sec = $(tab.getAttribute('href'));
  if (!sec) return;
  ScrollTrigger.create({ trigger: sec, start: 'top 50%', end: 'bottom 50%',
    onToggle: (st) => { if (st.isActive) document.querySelectorAll('.carte-tabs a').forEach((t) => t.classList.toggle('is-active', t === tab)); } });
});

/* ---------- Logo turns dark over light sections ---------- */
document.querySelectorAll('[data-logo="dark"]').forEach((sec) => {
  ScrollTrigger.create({ trigger: sec, start: 'top 70px', end: 'bottom 70px', toggleClass: { targets: '.logo', className: 'logo--dark' } });
});

/* ---------- Logo fade-in ---------- */
gsap.fromTo('.logo',
  { opacity: 0, y: -10, filter: 'blur(8px)' },
  { opacity: 1, y: 0, filter: 'blur(0px)', duration: 1.8, delay: 0.3, ease: 'power3.out' }
);
gsap.from('.corner', { opacity: 0, y: 20, duration: 1.4, delay: 0.9, stagger: 0.15, ease: 'power3.out' });

if (!reduceMotion) {
  /* ---------- Home 1. Hero: card rises through a slow background ---------- */
  if ($('.hero')) {
    const hero = { trigger: '.hero', start: 'top top', end: 'bottom bottom', scrub: SCRUB };
    gsap.to('.hero__card', {
      y: () => -(window.innerHeight + $('.hero__card').offsetHeight + 60),
      ease: 'none', force3D: true, scrollTrigger: { ...hero, invalidateOnRefresh: true },
    });
    if (!lite) gsap.to('.hero__bg', { yPercent: 8, scale: 1.08, ease: 'none', scrollTrigger: hero });
    gsap.to('.hero .corner', { y: -60, opacity: 0, ease: 'none',
      scrollTrigger: { trigger: '.hero', start: '60% bottom', end: 'bottom bottom', scrub: SCRUB } });
  }

  /* ---------- Sub page hero: title lines rise in, bg drifts ---------- */
  if ($('.page-hero')) {
    gsap.from('.page-hero__title .line', { yPercent: 100, opacity: 0, duration: 1.4, stagger: 0.1, delay: 0.4, ease: 'power4.out' });
    if (!lite) gsap.to('.page-hero__bg', { yPercent: 15, scale: 1.06, ease: 'none',
      scrollTrigger: { trigger: '.page-hero', start: 'top top', end: 'bottom top', scrub: true } });
    if (!lite) gsap.utils.toArray('.page-hero__title .line').forEach((line, i) => {
      gsap.to(line, { y: -(80 + i * 60), ease: 'none',
        scrollTrigger: { trigger: '.page-hero', start: 'top top', end: 'bottom top', scrub: true } });
    });
  }

  /* ---------- Words light up one by one ---------- */
  document.querySelectorAll('.js-words').forEach((el) => {
    gsap.to(splitWords(el), {
      opacity: 1, stagger: 0.05, ease: 'none',
      scrollTrigger: { trigger: el, start: 'top 75%', end: 'bottom 40%', scrub: SCRUB },
    });
  });

}

/* ---------- Desktop-only extras: parallax layers and slide-ins ---------- */
if (!reduceMotion && !lite) {
  /* ---------- Generic parallax: any element with data-speed ---------- */
  document.querySelectorAll('[data-speed]').forEach((el) => {
    const speed = parseFloat(el.dataset.speed);
    gsap.fromTo(el, { y: () => -speed * window.innerHeight * 0.5 }, {
      y: () => speed * window.innerHeight * 0.5, ease: 'none',
      scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true, invalidateOnRefresh: true },
    });
  });

  /* ---------- Home 3. Statement: bg slow, each line at its own speed ---------- */
  if ($('.statement')) {
    gsap.to('.statement__bg', { yPercent: 18, ease: 'none',
      scrollTrigger: { trigger: '.statement', start: 'top bottom', end: 'bottom top', scrub: true } });
    gsap.utils.toArray('.statement__title .line').forEach((line, i) => {
      gsap.from(line, { y: 120 + i * 70, ease: 'none',
        scrollTrigger: { trigger: '.statement', start: 'top bottom', end: 'top top', scrub: true } });
    });
    gsap.from('.statement__side', { y: 200, ease: 'none',
      scrollTrigger: { trigger: '.statement', start: 'top 60%', end: 'center center', scrub: true } });
  }

  /* ---------- Cards rise in a stagger ---------- */
  document.querySelectorAll('.cards').forEach((group) => {
    gsap.from(group.querySelectorAll('.card'), { y: 140, stagger: 0.08, ease: 'none',
      scrollTrigger: { trigger: group, start: 'top bottom', end: 'bottom 85%', scrub: true } });
  });

  /* ---------- Menu page: each list drifts up a little slower than the page ---------- */
  gsap.utils.toArray('.carte__body').forEach((body) => {
    gsap.from(body, { y: 60, ease: 'none',
      scrollTrigger: { trigger: body.closest('section'), start: 'top bottom', end: 'top 25%', scrub: true } });
  });

  /* ---------- Text blocks + footer logo ---------- */
  document.querySelectorAll('.order__intro').forEach((block) => {
    gsap.from(block, { y: 100, ease: 'none',
      scrollTrigger: { trigger: block.closest('section'), start: 'top bottom', end: 'top 30%', scrub: true } });
  });
  gsap.from('.footer__logo', { yPercent: 40, ease: 'none',
    scrollTrigger: { trigger: '.footer', start: 'top bottom', end: 'bottom bottom', scrub: true } });
}

window.addEventListener('load', () => ScrollTrigger.refresh());
